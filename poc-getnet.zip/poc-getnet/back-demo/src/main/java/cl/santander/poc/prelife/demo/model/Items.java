package cl.santander.poc.prelife.demo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class Items implements Serializable {

	private static final long serialVersionUID = 1800415630694384766L;

	private String sku;
	private String qty;
	private String price;

}
