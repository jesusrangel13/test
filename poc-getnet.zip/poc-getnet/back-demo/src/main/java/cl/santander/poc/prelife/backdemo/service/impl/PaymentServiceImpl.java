package cl.santander.poc.prelife.backdemo.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.santander.poc.prelife.backdemo.client.getnet.GetnetClientService;
import cl.santander.poc.prelife.backdemo.config.Config;
import cl.santander.poc.prelife.backdemo.service.PaymentService;
import cl.santander.poc.prelife.demo.model.Auth;
import cl.santander.poc.prelife.demo.model.InitTrxRequest;
import cl.santander.poc.prelife.demo.model.Metadata;
import cl.santander.poc.prelife.demo.model.RequestGetTransactionInformation;
import cl.santander.poc.prelife.demo.model.ResponseGetTransactionInformation;
import cl.santander.poc.prelife.demo.model.ResponseInitTrx;
import cl.santander.poc.prelife.demo.utils.Utils;

@Service
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	private Config config;

	@Autowired
	private GetnetClientService getnetApi;

	@Override
	public ResponseInitTrx createRequest(InitTrxRequest request) {

		// Se coloca el objeto de auth para getnet
		request.setAuth(generateAuthInfo());

		// llamar al servicio de getnet
		ResponseInitTrx response = getnetApi.createRequest(request).block();
		Metadata metaData = new Metadata();
		if (response.getStatus().getStatus().equalsIgnoreCase("failed")) {
			metaData.setMessage(response.getStatus().getReason() + ", " + response.getStatus().getMessage());
			metaData.setStatus(1);
		} else {
			metaData.setMessage(response.getStatus().getMessage());
			metaData.setStatus(0);
		}

		response.setMetadata(metaData);

		return response;
	}

	@Override
	public ResponseGetTransactionInformation getTransactionInformation(Integer requesId) {

		RequestGetTransactionInformation request = new RequestGetTransactionInformation();
		request.setAuth(generateAuthInfo());

		ResponseGetTransactionInformation response = getnetApi.getRequestInformation(request, requesId).block();

		Metadata metaData = new Metadata();
		if (response.getStatus().getStatus().equalsIgnoreCase("failed")) {
			metaData.setMessage(response.getStatus().getReason() + ", " + response.getStatus().getMessage());
			metaData.setStatus(1);
		} else {
			metaData.setMessage(response.getStatus().getMessage());
			metaData.setStatus(0);
		}

		response.setMetadata(metaData);

		return response;
	}

	private Auth generateAuthInfo() {

		// se obtiene los parametros para el auth
		String nonce = Utils.getNonce(false);
		String seed = Utils.getSeed();
		String tranKey = "";
		try {
			tranKey = Utils.getTrankey(true, nonce, seed, config.getSecretKey());
		} catch (Exception e) {
			e.printStackTrace();
		}

		// Se setea el objeto auth
		Auth auth = Auth.builder().login(config.getLogin()).nonce(Utils.base64(nonce.getBytes())).tranKey(tranKey)
				.seed(seed).build();

		return auth;

	}
}
