package cl.santander.poc.prelife.demo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class StatusResponse implements Serializable{
	
	private static final long serialVersionUID = -1592209700602101378L;
	
	private String status;
	private String reason;
	private String message;
	private String date;
	

}
