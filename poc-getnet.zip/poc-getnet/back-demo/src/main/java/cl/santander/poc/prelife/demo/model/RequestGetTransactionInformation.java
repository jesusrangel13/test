package cl.santander.poc.prelife.demo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class RequestGetTransactionInformation implements Serializable {

	private static final long serialVersionUID = 2188158961435551380L;
	private Auth auth;

}
