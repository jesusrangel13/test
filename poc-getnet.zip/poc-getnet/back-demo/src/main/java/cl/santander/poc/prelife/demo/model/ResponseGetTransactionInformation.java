package cl.santander.poc.prelife.demo.model;

import lombok.Data;

@Data
public class ResponseGetTransactionInformation {

	private static final long serialVersionUID = 5721061573433558553L;

	private Metadata metadata;
	private String requestId;
	private StatusResponse status;
	private Request request;

	private String returnUrl;
	private String ipAddress;
	private String userAgent;
	private String expiration;
	private boolean captureAddress;
	private boolean skipResult;
	private boolean noBuyerFill;

}
