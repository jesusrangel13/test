package cl.santander.poc.prelife.demo.model;

import java.io.Serializable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Auth implements Serializable {

	private static final long serialVersionUID = 3704216359359704855L;
	
	private String login;
	private String tranKey;
	private String nonce;
	private String seed;
	

}
