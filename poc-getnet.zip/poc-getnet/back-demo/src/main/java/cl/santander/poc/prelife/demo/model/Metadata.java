package cl.santander.poc.prelife.demo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class Metadata implements Serializable {

	private static final long serialVersionUID = -6491623580479379298L;

	private Integer status;
	private String message;

}
