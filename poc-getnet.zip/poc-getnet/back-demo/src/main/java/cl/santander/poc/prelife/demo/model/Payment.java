package cl.santander.poc.prelife.demo.model;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class Payment implements Serializable {

	private static final long serialVersionUID = -314053179544405379L;

	private String reference;
	private String description;
	private Amount amount;
	private boolean allowPartial;
	private boolean subscribe;
	private List<Items> items;
	private List<Fields> fields;

}
