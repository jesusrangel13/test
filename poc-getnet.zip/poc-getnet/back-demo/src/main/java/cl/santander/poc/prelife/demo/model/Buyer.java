package cl.santander.poc.prelife.demo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class Buyer implements Serializable {

	private static final long serialVersionUID = 310864212687986011L;

	private String name;
	private String surname;
	private String email;
	private String document;
	private String documentType;
	private Integer mobile;

}
