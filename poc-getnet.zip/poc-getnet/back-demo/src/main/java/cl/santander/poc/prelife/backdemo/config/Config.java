package cl.santander.poc.prelife.backdemo.config;

import java.io.Serializable;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

@Data
@Configuration
@ConfigurationProperties(prefix = "getnet")
public class Config implements Serializable {

	private static final long serialVersionUID = 8342049745750872533L;

	private String baseUrl;
	private String login;
	private String secretKey;
	private String createRequestPath;
	private String requestInformationPath;
	private String reversePaymentPath;

}
