package cl.santander.poc.prelife.demo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class Amount implements Serializable {

	private static final long serialVersionUID = 3084224927765987715L;
	
	private String currency;
	private Integer total;
	

}
