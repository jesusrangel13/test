package cl.santander.poc.prelife.backdemo.service;

import cl.santander.poc.prelife.demo.model.InitTrxRequest;
import cl.santander.poc.prelife.demo.model.ResponseGetTransactionInformation;
import cl.santander.poc.prelife.demo.model.ResponseInitTrx;

public interface PaymentService {

	ResponseInitTrx createRequest(InitTrxRequest request);

	ResponseGetTransactionInformation getTransactionInformation(Integer requesId);

}
