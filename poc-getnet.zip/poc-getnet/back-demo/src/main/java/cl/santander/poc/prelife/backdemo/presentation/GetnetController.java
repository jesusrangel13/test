package cl.santander.poc.prelife.backdemo.presentation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.santander.poc.prelife.backdemo.service.PaymentService;
import cl.santander.poc.prelife.demo.model.InitTrxRequest;
import cl.santander.poc.prelife.demo.model.ResponseGetTransactionInformation;
import cl.santander.poc.prelife.demo.model.ResponseInitTrx;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/v1/prelife")
public class GetnetController {

	@Autowired
	private PaymentService service;

	@CrossOrigin
	@PostMapping(value = "/initTransaction")
	public ResponseEntity<ResponseInitTrx> initTransaction(@RequestBody InitTrxRequest request) {

		log.info("init transaction");

		ResponseInitTrx response = service.createRequest(request);

		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	@CrossOrigin
	@GetMapping(value = "/transactionInformation/{requestId}")
	public ResponseEntity<ResponseGetTransactionInformation> getTransactionInformation(
			@PathVariable Integer requestId) {

		log.info("get transaction information requestId ", requestId);

		ResponseGetTransactionInformation response = service.getTransactionInformation(requestId);

		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

}
