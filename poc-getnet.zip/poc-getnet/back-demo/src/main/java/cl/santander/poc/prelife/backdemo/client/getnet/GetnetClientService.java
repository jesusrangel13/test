package cl.santander.poc.prelife.backdemo.client.getnet;

import cl.santander.poc.prelife.demo.model.InitTrxRequest;
import cl.santander.poc.prelife.demo.model.RequestGetTransactionInformation;
import cl.santander.poc.prelife.demo.model.ResponseGetTransactionInformation;
import cl.santander.poc.prelife.demo.model.ResponseInitTrx;
import reactor.core.publisher.Mono;

public interface GetnetClientService {

	Mono<ResponseInitTrx> createRequest(InitTrxRequest request);

	Mono<ResponseGetTransactionInformation> getRequestInformation(RequestGetTransactionInformation request,
			Integer idRequest);

}
