package cl.santander.poc.prelife.backdemo.client.getnet;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import cl.santander.poc.prelife.backdemo.config.Config;
import cl.santander.poc.prelife.demo.model.InitTrxRequest;
import cl.santander.poc.prelife.demo.model.RequestGetTransactionInformation;
import cl.santander.poc.prelife.demo.model.ResponseGetTransactionInformation;
import cl.santander.poc.prelife.demo.model.ResponseInitTrx;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class GetnetClientServiceImpl implements GetnetClientService {

	@Autowired
	private Config config;
	private WebClient clientGetnet;

	@PostConstruct
	public void init() {
		clientGetnet = WebClient.create(config.getBaseUrl());
	}

	@Override
	public Mono<ResponseInitTrx> createRequest(InitTrxRequest request) {

		log.info("Call createRequest GETNET {} ", request);

		return clientGetnet.post().uri(config.getCreateRequestPath()).bodyValue(request).exchangeToMono(response -> {
			if (response.statusCode().equals(HttpStatus.OK)) {
				return response.bodyToMono(ResponseInitTrx.class);
			} else if (response.statusCode().is4xxClientError()) {
				return response.bodyToMono(ResponseInitTrx.class);
			} else {
				return response.createException().flatMap(Mono::error);
			}
		});

	}

	@Override
	public Mono<ResponseGetTransactionInformation> getRequestInformation(RequestGetTransactionInformation request,
			Integer idRequest) {
		log.info("Call getRequestInformation GETNET {} ", request);
		
		System.out.println(String.format(config.getRequestInformationPath(), idRequest));

		return clientGetnet.post().uri(String.format(config.getRequestInformationPath(), idRequest)).bodyValue(request).exchangeToMono(response -> {
			if (response.statusCode().equals(HttpStatus.OK)) {
				return response.bodyToMono(ResponseGetTransactionInformation.class);
			} else if (response.statusCode().is4xxClientError()) {
				return response.bodyToMono(ResponseGetTransactionInformation.class);
			} else {
				return response.createException().flatMap(Mono::error);
			}
		});
	}

}
