package cl.santander.poc.prelife.demo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class ResponseInitTrx implements Serializable {

	private static final long serialVersionUID = 5965414345060391966L;

	private Metadata metadata;
	private StatusResponse status;
	private Integer requestId;
	private String processUrl;

}
