package cl.santander.poc.prelife.demo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class InitTrxRequest implements Serializable {

	private static final long serialVersionUID = 1772111375946090713L;

	private Auth auth;
	private String locale;
	private Buyer buyer;
	private Payment payment;
	private String expiration;
	private String returnUrl;
	private String cancelUrl;
	private String userAgent;
	private String ipAddress;

}
