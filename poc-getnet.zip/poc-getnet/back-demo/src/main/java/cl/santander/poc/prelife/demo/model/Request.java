package cl.santander.poc.prelife.demo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class Request implements Serializable {
	
	private static final long serialVersionUID = 8098126531727251258L;
	
	private String locale;
	private Payment payment;
	private Buyer buyer;

}
