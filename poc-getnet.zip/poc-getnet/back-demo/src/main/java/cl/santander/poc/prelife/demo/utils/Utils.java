package cl.santander.poc.prelife.demo.utils;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Locale;

public class Utils {

	public static String getSeed() {
		return (new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.getDefault())).format(new Date());
		
	}

	public static String getNonce(boolean encoded) {
		String nonce = new BigInteger(130, new SecureRandom()).toString(16);
		if (encoded)
			return base64(nonce.getBytes());
		return nonce;
	}

	public static String base64(byte[] input) {
		byte[] encodedBytes = (Base64.getEncoder()).encode(input);
		return new String(encodedBytes);
	}

	public static String getTrankey(boolean encoded, String nonce, String seed, String secret) throws Exception {
		try {
			byte[] digest = sha1(nonce + seed + secret);
			if (encoded)
				return base64(digest);
			return new String(digest);
		} catch (NoSuchAlgorithmException ex) {
			throw new Exception(ex.getMessage());
		}
	}

	public static byte[] sha1(String input) throws NoSuchAlgorithmException {
		MessageDigest mDigest = MessageDigest.getInstance("SHA1");
		return mDigest.digest(input.getBytes());
	}

}
