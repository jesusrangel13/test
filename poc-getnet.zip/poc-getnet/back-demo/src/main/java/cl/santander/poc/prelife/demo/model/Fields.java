package cl.santander.poc.prelife.demo.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class Fields implements Serializable {

	private static final long serialVersionUID = 5028565963612902864L;

	private String keyword;
	private String value;

}
