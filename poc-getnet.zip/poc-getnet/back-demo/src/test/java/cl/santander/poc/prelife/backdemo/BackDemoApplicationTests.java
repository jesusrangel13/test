package cl.santander.poc.prelife.backdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
