package cl.lab.transformMessage.config;

import cl.lab.transformMessage.dto.ConfigDTO;
import cl.lab.transformMessage.dto.RequestDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Configuration;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.ResourceUtils;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
@Slf4j
public class SimpleRouteBuilder extends RouteBuilder {

    @Autowired
    RequestDTO config;

    @Value("classpath:template.json")
    Resource resourceFile;

    public void configure() throws Exception {
        System.out.println("pasa");
        //String topicName = "topic=topic1";
        //String kafkaServer = "kafka:localhost:9092";
        //String zooKeeperHost = "zookeeperHost=localhost&zookeeperPort=2181";
        //String serializerClass = "serializerClass=kafka.serializer.StringEncoder";


        config.getConfigurations().forEach(res-> {
            String toKafkaFrom = "kafka:"+res.getIn().getTopic()+"?brokers="+res.getIn().getUrl();
            String toKafkaTo = "kafka:"+res.getOut().getTopic()+"?brokers="+res.getOut().getUrl();

            from(toKafkaFrom)
                    //.unmarshal()
                    //.marshal()
                    .process(exchange -> {
                        log.info("===== COMENZANDO CONVERSION =====");
                        Map<String, String> map = new HashMap<>();
                        //topico de entrada
                        String topic = exchange.getIn().getHeaders().get("kafka.TOPIC").toString();
                        String message = exchange.getIn().getBody(String.class);

                        config.getConfigurations().stream()
                                .filter(val -> val.getIn().getTopic().equalsIgnoreCase(topic))
                                .findFirst()
                                .ifPresent(configDTO -> configDTO.getParams().forEach((key, value) -> {
                                    map.put(key, getValue(message, value));
                                }));
                        byte[] byteData = FileCopyUtils.copyToByteArray(resourceFile.getInputStream());
                        String template = new String(byteData, StandardCharsets.UTF_8);

                        for(Map.Entry<String, String> obj : map.entrySet()) {
                            template = template.replaceAll("\\$\\{"+obj.getKey()+"\\}", obj.getValue());
                        }

                        exchange.getIn().setBody(template);

                        log.info("===== CONVERSION FINALIZADA =====");
                    })
                    .to(toKafkaTo)
                    .end();

            from(toKafkaTo)
                    .log("mensaje de entrada: ${body}")
                    .end();
        });
    }

    private String getValue(String json, String path) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            JsonNode jsonNode = objectMapper.readTree(json);
            String[] pathArray = path.split("/");
            Pattern pattern = Pattern.compile("^(.*)\\[(\\d+)]$");
            for (int i = 0; i < pathArray.length; i++) {
                if (!pathArray[i].isBlank()) {
                    Matcher matcher = pattern.matcher(pathArray[i]);
                    String path_ = pathArray[i];
                    int index = -1;
                    if (matcher.matches()) {
                        path_ = matcher.group(1);
                        index = Integer.parseInt(matcher.group(2));
                    }
                    System.out.println("Evaluando: " + path_);
                    jsonNode = jsonNode.get(path_);
                    if (index > -1) {
                        jsonNode = jsonNode.get(index);
                    }
                }
                if (jsonNode.isNull()) {
                    throw new JsonMappingException("ruta no existe");
                }
            }
            System.out.println("Resultado: " + jsonNode.asText());
            return jsonNode.asText();
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }
}

