package cl.lab.transformMessage.service;

public interface KafkaService {
    void sendMessage(Object message) throws Exception;
}
