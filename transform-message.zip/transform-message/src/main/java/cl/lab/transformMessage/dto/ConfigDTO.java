package cl.lab.transformMessage.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConfigDTO {
    private TopicDTO in;
    private TopicDTO out;
    private HashMap<String, String> params;
}
