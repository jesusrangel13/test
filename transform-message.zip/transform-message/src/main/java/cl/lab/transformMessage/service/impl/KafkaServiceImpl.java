package cl.lab.transformMessage.service.impl;

import cl.lab.transformMessage.service.KafkaService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
@Slf4j
public class KafkaServiceImpl implements KafkaService {

    private static final String TOPIC_FROM = "topic1";

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    public void sendMessage(Object message) throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        log.info(String.format("#### -> Producing message -> %s", message));
        kafkaTemplate.send(TOPIC_FROM, objectMapper.writeValueAsString(message));
    }

    //@KafkaListener(topics = "java_in_use_topic1", groupId = "group_id")
    public void consume(String message) throws IOException {
        log.info(String.format("#### -> Consumed message -> %s", message));
    }
}
