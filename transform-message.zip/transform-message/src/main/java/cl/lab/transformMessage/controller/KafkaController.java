package cl.lab.transformMessage.controller;

import cl.lab.transformMessage.service.KafkaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "api", consumes = MediaType.APPLICATION_JSON_VALUE)
public class KafkaController {

    @Autowired
    KafkaService kafkaService;

    @GetMapping("producer")
    public String producer(@RequestBody Object object) {
        try {
            kafkaService.sendMessage(object);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "Envio de mensaje al topico de kafka java_in_use_topic exitoso";
    }
}
