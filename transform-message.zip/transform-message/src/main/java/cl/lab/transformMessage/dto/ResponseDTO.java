package cl.lab.transformMessage.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseDTO {
    private String CodDHW;
    private String Monto;
    private String Codigo;
    private String Date;
    private String Mensaje5;
    private String Mensaje2;
    private String txname;
    private String Transa;
    private String NroServidor;
    private String Mensaje6;
    private String Mensaje4;
    private String Mensaje9;
    private String TiempoMdw;
    private String Mensaje7;
    private String CtaDst;
    private String IpCliente;
    private String Mensaje8;
    private String Mensaje1;
    private String Flgextcn;
    private String TiempoRespuesta;
    private String tpo;
    private String Mensaje3;
    private String Uri;
    private String Descripcion;
    private String RutCliente;
    private String timestamp;
    private String version;
    private String CtaOrg;
}
