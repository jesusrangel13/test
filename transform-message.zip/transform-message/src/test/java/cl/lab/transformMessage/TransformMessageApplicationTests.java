package cl.lab.transformMessage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransformMessageApplicationTests {

	@Test
	void contextLoads() {
	}

}
